﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KólkoKrzyżyk
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        bool notWin = true;         //turn -> true = "X" , false = "O"
        bool gameOver = false;
        string winner = "";

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Button b = (Button)sender;
                if (gameOver == false)
                {
                    if (notWin == true)
                    {
                        b.Text = "X";
                        notWin = !notWin;
                        label1.Text = "Kolejny gracz  O";
                    }
                    else
                    {
                        b.Text = "O";
                        label1.Text = "Kolejny gracz  X";
                        notWin = !notWin;
                    }
                }
                check(); 
            }
            catch { }
        }

        public void check()
        {
            bool thereIsAWinner = false;

            if ((button1.Text == button2.Text) && (button2.Text == button3.Text) && button1.Text != "")
            {
                thereIsAWinner = true;
                gameOver = true;
            }
            else if ((button6.Text == button5.Text) && (button5.Text == button4.Text) && button6.Text != "")
            {
                thereIsAWinner = true;
                gameOver = true;
            }
            else if ((button7.Text == button8.Text) && (button8.Text == button9.Text) && button7.Text != "")
            {
                thereIsAWinner = true;
                gameOver = true;
            }

            else if ((button1.Text == button6.Text) && (button6.Text == button7.Text) && button6.Text != "")
            {
                thereIsAWinner = true;
                gameOver = true;
            }
            else if ((button2.Text == button5.Text) && (button5.Text == button8.Text) && button5.Text != "")
            {
                thereIsAWinner = true;
                gameOver = true;
            }
            else if ((button3.Text == button4.Text) && (button4.Text == button9.Text) && button4.Text != "")
            {
                thereIsAWinner = true;
                gameOver = true;
            }

            else if ((button1.Text == button5.Text) && (button5.Text == button9.Text) && button1.Text != "")
            {
                thereIsAWinner = true;
                gameOver = true;
            }
            else if ((button3.Text == button5.Text) && (button5.Text == button7.Text) && button5.Text != "")
            {
                thereIsAWinner = true;
                gameOver = true;
            }
             
            if (thereIsAWinner)
            {               
                if (notWin)
                    winner = "O";
                else 
                    winner = "X";
                label1.Text = "Wygrał gracz  " + winner;           //MessageBox.Show("Wygrał " + winner);
                notWin = false;
            }
            else if (button1.Text != "" && button2.Text != "" && button3.Text != "" && button4.Text != "" && button5.Text != "" && button6.Text != "" && button7.Text != "" && button8.Text != "" && button9.Text != "")
            {
                label1.Text = "Remis";           //MessageBox.Show("Remis");
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            gameOver = false;

            if (winner == "X")
            {
                label1.Text = "Kolejny gracz  O";
            }
            else
            {
                notWin = true;
                label1.Text = "Kolejny gracz  X";
            }

            button1.Text = "";
            button2.Text = "";
            button3.Text = "";
            button4.Text = "";
            button5.Text = "";
            button6.Text = "";
            button7.Text = "";
            button8.Text = "";
            button9.Text = "";
        }
    }
}


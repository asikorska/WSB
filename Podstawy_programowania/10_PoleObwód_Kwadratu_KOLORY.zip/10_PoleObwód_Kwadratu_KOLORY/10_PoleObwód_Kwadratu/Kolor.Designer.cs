﻿namespace _10_PoleObwód_Kwadratu
{
    partial class Kolor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnZamknijKolor = new System.Windows.Forms.Button();
            this.btnZamknijProgramKolor = new System.Windows.Forms.Button();
            this.btnZmieńKolor = new System.Windows.Forms.Button();
            this.btnPokaż = new System.Windows.Forms.Button();
            this.txtBokKolor = new System.Windows.Forms.TextBox();
            this.lblBokKolor = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblInfo = new System.Windows.Forms.Label();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnZamknijKolor
            // 
            this.btnZamknijKolor.Location = new System.Drawing.Point(53, 273);
            this.btnZamknijKolor.Name = "btnZamknijKolor";
            this.btnZamknijKolor.Size = new System.Drawing.Size(107, 28);
            this.btnZamknijKolor.TabIndex = 9;
            this.btnZamknijKolor.Text = "Zamknij";
            this.btnZamknijKolor.UseVisualStyleBackColor = true;
            this.btnZamknijKolor.Click += new System.EventHandler(this.btnZamknijKolor_Click);
            // 
            // btnZamknijProgramKolor
            // 
            this.btnZamknijProgramKolor.Location = new System.Drawing.Point(252, 273);
            this.btnZamknijProgramKolor.Name = "btnZamknijProgramKolor";
            this.btnZamknijProgramKolor.Size = new System.Drawing.Size(107, 28);
            this.btnZamknijProgramKolor.TabIndex = 10;
            this.btnZamknijProgramKolor.Text = "Zamknij program";
            this.btnZamknijProgramKolor.UseVisualStyleBackColor = true;
            this.btnZamknijProgramKolor.Click += new System.EventHandler(this.btnZamknijProgramKolor_Click);
            // 
            // btnZmieńKolor
            // 
            this.btnZmieńKolor.Location = new System.Drawing.Point(53, 187);
            this.btnZmieńKolor.Name = "btnZmieńKolor";
            this.btnZmieńKolor.Size = new System.Drawing.Size(107, 28);
            this.btnZmieńKolor.TabIndex = 11;
            this.btnZmieńKolor.Text = "Zmień kolor";
            this.btnZmieńKolor.UseVisualStyleBackColor = true;
            this.btnZmieńKolor.Click += new System.EventHandler(this.btnZmieńKolor_Click);
            // 
            // btnPokaż
            // 
            this.btnPokaż.Location = new System.Drawing.Point(83, 128);
            this.btnPokaż.Name = "btnPokaż";
            this.btnPokaż.Size = new System.Drawing.Size(77, 28);
            this.btnPokaż.TabIndex = 12;
            this.btnPokaż.Text = "Pokaż";
            this.btnPokaż.UseVisualStyleBackColor = true;
            this.btnPokaż.Click += new System.EventHandler(this.btnPokaż_Click);
            // 
            // txtBokKolor
            // 
            this.txtBokKolor.Location = new System.Drawing.Point(54, 76);
            this.txtBokKolor.Name = "txtBokKolor";
            this.txtBokKolor.Size = new System.Drawing.Size(106, 20);
            this.txtBokKolor.TabIndex = 14;
            this.txtBokKolor.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtBokKolor.TextChanged += new System.EventHandler(this.txtBokKolor_TextChanged);
            // 
            // lblBokKolor
            // 
            this.lblBokKolor.AutoSize = true;
            this.lblBokKolor.Location = new System.Drawing.Point(22, 79);
            this.lblBokKolor.Name = "lblBokKolor";
            this.lblBokKolor.Size = new System.Drawing.Size(26, 13);
            this.lblBokKolor.TabIndex = 13;
            this.lblBokKolor.Text = "Bok";
            this.lblBokKolor.Click += new System.EventHandler(this.lblBokKolor_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Location = new System.Drawing.Point(183, 43);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(0, 0);
            this.panel1.TabIndex = 15;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // lblInfo
            // 
            this.lblInfo.AutoSize = true;
            this.lblInfo.ForeColor = System.Drawing.Color.Red;
            this.lblInfo.Location = new System.Drawing.Point(38, 43);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(122, 13);
            this.lblInfo.TabIndex = 16;
            this.lblInfo.Text = "Podaj prawidłowe dane!";
            this.lblInfo.Visible = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(407, 24);
            this.menuStrip1.TabIndex = 17;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.closeToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.newToolStripMenuItem.Text = "New";
            this.newToolStripMenuItem.Click += new System.EventHandler(this.newToolStripMenuItem_Click);
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new System.EventHandler(this.closeToolStripMenuItem_Click);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // Kolor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(407, 331);
            this.Controls.Add(this.lblInfo);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.txtBokKolor);
            this.Controls.Add(this.lblBokKolor);
            this.Controls.Add(this.btnPokaż);
            this.Controls.Add(this.btnZmieńKolor);
            this.Controls.Add(this.btnZamknijProgramKolor);
            this.Controls.Add(this.btnZamknijKolor);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Kolor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Kolor";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnZamknijKolor;
        private System.Windows.Forms.Button btnZamknijProgramKolor;
        private System.Windows.Forms.Button btnZmieńKolor;
        private System.Windows.Forms.Button btnPokaż;
        private System.Windows.Forms.TextBox txtBokKolor;
        private System.Windows.Forms.Label lblBokKolor;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblInfo;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _10_PoleObwód_Kwadratu
{
    public partial class Kolor : Form
    {
        public Kolor()
        {
            InitializeComponent();
        }

        
        private void btnZamknijProgramKolor_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnZamknijKolor_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtBokKolor_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblBokKolor_Click(object sender, EventArgs e)
        {

        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnPokaż_Click(object sender, EventArgs e)
        {
            int bok;
            if (int.TryParse(txtBokKolor.Text, out bok) && bok > 0 && bok <=200)
            {
                panel1.Height = bok;
                panel1.Width = bok;
                lblInfo.Visible = false;
            }
            else
            {
                lblInfo.Visible = true;
            }
        }

        private void btnZmieńKolor_Click(object sender, EventArgs e)
        {
            colorDialog1.ShowDialog();
            panel1.BackColor = colorDialog1.Color;
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            draw d = new draw();
            d.ShowDialog();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _10_PoleObwód_Kwadratu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void label4_Click(object sender, EventArgs e)
        {
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtBok_TextChanged(object sender, EventArgs e)
        {      
            double bok;
            if(double.TryParse(txtBok.Text,out bok) && bok > 0)
            {
                txtPole.Text = Math.Pow(bok, 2).ToString();
                txtObwod.Text = (4 * bok).ToString();
                lblKomunikat.Text = String.Empty;
            }
            else
            {
                lblKomunikat.Text = "Wpisz liczbę dodatnią!";
                txtPole.Text = String.Empty;
                txtObwod.Text = String.Empty;
            }
        }

        private void txtObwod_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPole_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblBok_Click(object sender, EventArgs e)
        {

        }

        private void lblObwód_Click(object sender, EventArgs e)
        {

        }

        private void lblPole_Click(object sender, EventArgs e)
        {

        }

        private void btnWyczysc_Click(object sender, EventArgs e)
        {
            txtBok.Text = String.Empty;            
            lblKomunikat.Text = "Wpisz wymiar boku";
        }

        private void btnZamknij_Click(object sender, EventArgs e)
        {
            Application.Exit();
            //this.Close();
        }

        private void lblKomunikat_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnKolor_Click(object sender, EventArgs e)
        {
            var formKolor = new Kolor();
            formKolor.Show();
        }
    }
}

﻿namespace _10_PoleObwód_Kwadratu
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblBok = new System.Windows.Forms.Label();
            this.lblObwód = new System.Windows.Forms.Label();
            this.lblPole = new System.Windows.Forms.Label();
            this.txtBok = new System.Windows.Forms.TextBox();
            this.txtPole = new System.Windows.Forms.TextBox();
            this.txtObwod = new System.Windows.Forms.TextBox();
            this.btnWyczysc = new System.Windows.Forms.Button();
            this.btnZamknij = new System.Windows.Forms.Button();
            this.lblKomunikat = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblBok
            // 
            this.lblBok.AutoSize = true;
            this.lblBok.Location = new System.Drawing.Point(75, 64);
            this.lblBok.Name = "lblBok";
            this.lblBok.Size = new System.Drawing.Size(26, 13);
            this.lblBok.TabIndex = 0;
            this.lblBok.Text = "Bok";
            this.lblBok.Click += new System.EventHandler(this.lblBok_Click);
            // 
            // lblObwód
            // 
            this.lblObwód.AutoSize = true;
            this.lblObwód.Location = new System.Drawing.Point(60, 116);
            this.lblObwód.Name = "lblObwód";
            this.lblObwód.Size = new System.Drawing.Size(41, 13);
            this.lblObwód.TabIndex = 1;
            this.lblObwód.Text = "Obwód";
            this.lblObwód.Click += new System.EventHandler(this.lblObwód_Click);
            // 
            // lblPole
            // 
            this.lblPole.AutoSize = true;
            this.lblPole.Location = new System.Drawing.Point(73, 166);
            this.lblPole.Name = "lblPole";
            this.lblPole.Size = new System.Drawing.Size(28, 13);
            this.lblPole.TabIndex = 2;
            this.lblPole.Text = "Pole";
            this.lblPole.Click += new System.EventHandler(this.lblPole_Click);
            // 
            // txtBok
            // 
            this.txtBok.Location = new System.Drawing.Point(125, 61);
            this.txtBok.Name = "txtBok";
            this.txtBok.Size = new System.Drawing.Size(158, 20);
            this.txtBok.TabIndex = 4;
            this.txtBok.TextChanged += new System.EventHandler(this.txtBok_TextChanged);
            // 
            // txtPole
            // 
            this.txtPole.Enabled = false;
            this.txtPole.Location = new System.Drawing.Point(125, 163);
            this.txtPole.Name = "txtPole";
            this.txtPole.Size = new System.Drawing.Size(158, 20);
            this.txtPole.TabIndex = 5;
            this.txtPole.TextChanged += new System.EventHandler(this.txtPole_TextChanged);
            // 
            // txtObwod
            // 
            this.txtObwod.Enabled = false;
            this.txtObwod.Location = new System.Drawing.Point(125, 113);
            this.txtObwod.Name = "txtObwod";
            this.txtObwod.Size = new System.Drawing.Size(158, 20);
            this.txtObwod.TabIndex = 6;
            this.txtObwod.TextChanged += new System.EventHandler(this.txtObwod_TextChanged);
            // 
            // btnWyczysc
            // 
            this.btnWyczysc.Location = new System.Drawing.Point(86, 207);
            this.btnWyczysc.Name = "btnWyczysc";
            this.btnWyczysc.Size = new System.Drawing.Size(107, 28);
            this.btnWyczysc.TabIndex = 7;
            this.btnWyczysc.Text = "Wyczyść";
            this.btnWyczysc.UseVisualStyleBackColor = true;
            this.btnWyczysc.Click += new System.EventHandler(this.btnWyczysc_Click);
            // 
            // btnZamknij
            // 
            this.btnZamknij.Location = new System.Drawing.Point(210, 207);
            this.btnZamknij.Name = "btnZamknij";
            this.btnZamknij.Size = new System.Drawing.Size(107, 28);
            this.btnZamknij.TabIndex = 8;
            this.btnZamknij.Text = "Zamknij";
            this.btnZamknij.UseVisualStyleBackColor = true;
            this.btnZamknij.Click += new System.EventHandler(this.btnZamknij_Click);
            // 
            // lblKomunikat
            // 
            this.lblKomunikat.AutoSize = true;
            this.lblKomunikat.ForeColor = System.Drawing.Color.Red;
            this.lblKomunikat.Location = new System.Drawing.Point(308, 64);
            this.lblKomunikat.Name = "lblKomunikat";
            this.lblKomunikat.Size = new System.Drawing.Size(0, 13);
            this.lblKomunikat.TabIndex = 9;
            this.lblKomunikat.Click += new System.EventHandler(this.lblKomunikat_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(460, 311);
            this.Controls.Add(this.lblKomunikat);
            this.Controls.Add(this.btnZamknij);
            this.Controls.Add(this.btnWyczysc);
            this.Controls.Add(this.txtObwod);
            this.Controls.Add(this.txtPole);
            this.Controls.Add(this.txtBok);
            this.Controls.Add(this.lblPole);
            this.Controls.Add(this.lblObwód);
            this.Controls.Add(this.lblBok);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblBok;
        private System.Windows.Forms.Label lblObwód;
        private System.Windows.Forms.Label lblPole;
        private System.Windows.Forms.TextBox txtBok;
        private System.Windows.Forms.TextBox txtPole;
        private System.Windows.Forms.TextBox txtObwod;
        private System.Windows.Forms.Button btnWyczysc;
        private System.Windows.Forms.Button btnZamknij;
        private System.Windows.Forms.Label lblKomunikat;
    }
}

